Create database Amdocsdatabase;

CREATE TABLE Usuarios(
  Email Varchar(20),
  Password Varchar(20),
  Role Varchar(15),
  Username Varchar(30),
  Primary Key (Email)
  );

CREATE TABLE Candidates(
IdNumber int,
CandidateName Varchar(20),
Partner Varchar (20),
CandidateRole Varchar (20),
Pi int,
Pcenter Varchar(20),
Ql3 Varchar(20),
Req int,
FWD date,
Mgr Varchar(20),
Tentative date ,
Site Varchar(20),
Wcm_Bd Varchar(20),
Primary Key (Idnumber)
);

create table Estatus(
IdNumber int,
NumEtapa int,
FechaInicio date,
FechaFin date,
Flag bool,
primary key(NumEtapa),
FOREIGN KEY (IdNumber) REFERENCES Candidates(IdNumber)
);

create table Etapa(
NumEtapa int,
IdEtapa int,
DuracionEtapa int,
Requisitos varchar(50),
Deadline int,
FOREIGN KEY (NumEtapa) REFERENCES Candidates(NumEtapa)
);


