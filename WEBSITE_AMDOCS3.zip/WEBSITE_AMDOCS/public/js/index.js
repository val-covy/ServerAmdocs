const signInBtn = document.querySelector('.button-login');
const email = document.querySelector(".login [type='email']");
const password = document.querySelector(".login [type='password']");

signInBtn.addEventListener("click", e => {
    var body = JSON.stringify({
        email: email.value,
        password: password.value});
    fetch("http://localhost:8080/api/auth/signin", {
        method: 'POST',
        body: body,
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(json => {
        if(json.accessToken){
            localStorage.setItem('UserInfo', JSON.stringify(json));
            if(json.roles.includes('ROLE_ADMIN')) {
                location.href = "http://localhost:8080/inicio_administrador.html"
            } else if(json.roles.includes('ROLE_CONSULTANT')) {
                location.href = "http://localhost:8080/inicio_consultant.html"
            } else if(json.roles.includes('GENERAL_ADMIN')) {
                location.href = "http://localhost:8080/inicio_general.html"
            } 
        } else {
            console.log(json.message);
        }
    });
});