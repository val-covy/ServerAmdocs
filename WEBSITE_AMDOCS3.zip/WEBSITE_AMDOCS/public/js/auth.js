function logout() {
    localStorage.removeItem('UserInfo');
    localStorage.href = "http://localhost:8080/index.html";
}

var user = JSON.parse(localStorage.getItem('UserInfo'));
if(!user) { 
    console.log("User not authenticated");
    location.href = "http://localhost:8080/index.html";
} else {
    let token = user.accessToken;
    fetch("https://localhost:8080/api/auth/isAuthenticated", {
        method: 'GET',
        headers: {
            'x-access-token': token
        }
    })
    .then(response => response.json())
    .then(json => {
        if(json.message !== "Authenticated") {
            console.log("The token has expired");
            logout();
        } else {
            fetch("http://localhost:8080/api/general/access", {
                method: "GET",
                headers: {
                    'x-access-token': token
                }
            })
            .then(response => response.json())
            .then(json => {
                if (json.resources.includes(location.pathname)) {
                    console.log("You don't have access to this resource");
                    location.href = "http://localhost:8080/access_denied.html"; //Necesitamos pagina de access denied o no se cual sea xd
                }
            });
        }
    });
}