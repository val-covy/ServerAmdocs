function addlocalid(localid){
    var params = new URLSearchParams();
    params.append("localid",JSON.stringify(localid));
    var url = "fases_administrator.html?" + params.toString();
    location.href = url;
}


function appendData(data){
    var table = document.getElementById('allCand')
    for (var i = 0;i<data.length;i++){
        var row = `<tr>
            <td> <a href="fases_consultant.html" onClick={this.addlocalid(${data[i].idCandidato})} > ${data[i].idCandidato}</a> </td>
            <td>${data[i].name}</td>
            <td>${data[i].role}</td>
            <td><button onClick={addlocalid(${data[i].idCandidato})}> btn </button></td>
            </tr>`
        table.innerHTML += row
    }
};
//a href="fases_consultant.html">View Profile</a>


fetch("http://localhost:8080/api/auth/allCandidates",{
    method:"GET"
}).then(function(response){
    return response.json();
}).then(function(data){
    appendData(data);
}).catch(function(err){
    console.log(err);
});

//---------

function appendDataFlag(data){
    var table = document.getElementById('candFlag')
    for (var i = 0;i<data.length;i++){
        var row = `<tr>
            <td>${data[i].name}</td>
            <td>${data[i].role}</td>
            </tr>`
        table.innerHTML += row
    }
}


fetch("http://localhost:8080/api/auth/allCandidatesWithFlag",{
    method:"GET"
}).then(function(response){
    return response.json();
}).then(function(data){
    appendDataFlag(data);
}).catch(function(err){
    console.log(err);
});



