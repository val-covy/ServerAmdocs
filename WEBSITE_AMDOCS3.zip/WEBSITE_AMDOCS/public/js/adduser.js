const email = document.querySelector(".login [type='email']");
const password = document.querySelector(".login [type='password']");
const username = document.querySelector(".login [type='username']");
const okBtn = document.querySelector(".button-create");
const selection = document.querySelector('select');
var user = JSON.parse(localStorage.getItem("UserInfo"));
console.log(email);

okBtn.addEventListener("click", e => {
  fetch("http://localhost:8080/api/auth/signup",{     //Mandar http request
    method:'POST',
    body:JSON.stringify({ //Agregas los request
      username:  username.value,
      email: email.value,
      password: password.value,
      roles:[selection.options[selection.selectedIndex].value]
    }),
    headers: {
      'Content-Type' : 'application/json',
      'x-access-token': user.accessToken // especificas que tipo de dato estas mandando en el body
    }
  }).then(response => response.json())
    .then(json => {
      console.log(JSON.stringify(json,null,2));
  });
});