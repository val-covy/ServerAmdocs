const rows = document.querySelectorAll("tbody tr");
const acceptBtn = document.querySelectorAll(".button-accept");
//const emailToDelete = document.querySelector(".erraser [type='email']");
//const confirmBtn = document.querySelectorAll(".button-confirm");


function appendData(data){
    var table = document.getElementById('myTable')
    for (var i = 0;i<data.length;i++){
        var row = `<tr>
            <td>${data[i].username}</td>
            <td>${data[i].email}</td>
            <td>${data[i].id}</td>
            </tr>`
        table.innerHTML += row
    }
}


fetch("http://localhost:8080/api/auth/allUsers",{
    method:"GET"
}).then(function(response){
    return response.json();
}).then(function(data){
    appendData(data);
}).catch(function(err){
    console.log(err);
});



 // <td style="text-align: left; background-color: white; border: none;"><a href="#openPopup" aria-label="Delete"><i class="fas fa-trash-alt fa-1x" aria-hidden="true" style="color: red;"></i></a></td>
    

/*   
   for (var i = 0; i < data.length; i++){
 var div = document.createElement("div");
        div.innerHTML = 'username '+ data[i].username + ' email '+ data[i].email + ' id '+ data[i].id;
        mainContainer.appendChild(div);

}
}

fetch("http://localhost:8080/api/auth/allUsers",{
    method:"GET"
}).then(response => response.json())
.then(json => {
    json.data.forEach(element =>{
        tablaUsers.innerHTML +=<tr><td>element</td><td>element</td><td>element</td></tr>
    });
});
*/
/*function appendData(data){
    var mainContainer = document.getElementById("myData");
    for (let i = 0; i < data.length; i++) {
        rows[i].querySelectorAll("td").forEach((column, indx) => {
            switch(indx) {
                case 0:
                    column.innerHTML = data[i].username;
                    break;
                case 1:
                    column.innerHTML = data[i].email ;
                    break;
                case 2:
                    column.innerHTML = "id " + data[i].id ;
                    break;
                default:
                    break;
            }
        });
    }
}
*/
   
   
   
   
   
