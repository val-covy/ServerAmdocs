function get(){
    var params = new URLSearchParams(window.location.search);
    var localid = JSON.parse(params.get("localid"));
    console.log(localid);
    return localid;
}

var getter = get()

/*fetch("http://localhost:8080/api/auth/allUsers", {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    }

})*/


function appendData(data){
    var table = document.getElementById('Name')
    for (var i = 0;i<data.length;i++){
        var row = `<p>
            ${data[i].name},
            ${data[i].role}
            </p>`
        table.innerHTML += row
    }
};
//a href="fases_consultant.html">View Profile</a>

fetch("http://localhost:8080/api/auth/Idcandidate",{
    method:"POST",
    body: JSON.stringify({
        idCandidato: get(),
        headers:{
            'Content-Type' : 'application/json'
          }
    }),
}).then(function(response){
    return response.json();
}).then(function(data){
    appendData(data);
}).catch(function(err){
    console.log(err);
});
