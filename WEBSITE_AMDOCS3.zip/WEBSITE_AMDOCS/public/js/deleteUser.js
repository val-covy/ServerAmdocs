const emailToDelete = document.querySelector(".erraser [type='email']");
const confirmBtn = document.querySelector(".button-confirm");

/*function del(){
  fetch("http://localhost:8080/api/auth/errase",{
      method:'DELETE',
      body:JSON.stringify({
          email:emailToDelete.value,
      headers: {
          'Content-Type' : 'application/json'
      }
  })
});
}*/


confirmBtn.addEventListener("click", e => {
  fetch("http://localhost:8080/api/auth/errase",{
    method: 'DELETE',
    body: JSON.stringify({
      email:emailToDelete.value,
    }),
    headers:{
      'Content-Type' : 'application/json'
    }
  });
});
  


  /*
});
/*
confirmBtn.addEventListener("click", e => {
  fetch("http://localhost:8080/api/auth/errase",{
      method:'DELETE',
      body:JSON.stringify({
          email:emailToDelete.value,
      headers: {
          'Content-Type' : 'application/json'
      }
  })
});
});


/*<td style="text-align: left; background-color: white; border: none;">
                          <a href="#openPopup" aria-label="Delete">
                              <i class="fas fa-trash-alt fa-1x" aria-hidden="true" style="color: red;"></i>
                          </a>
                      </td>*/
/*function appendData(data){
  var mainContainer = document.getElementById("myData");





// const email = document.querySelector(".login [type='email']");
// const password = document.querySelector(".login [type='password']");
// const username = document.querySelector(".login [type='username']");
// const delBtn = document.querySelector(".Yes-btn button");
// const position = document.querySelector(".login [type='role']");
// var user = JSON.parse(localStorage.getItem("UserInfo"));
// console.log(email);

/*
delBtn.addEventListener("click", e => {
  fetch("http://localhost:8080/api/auth/",{     //Mandar http request
    method:'GET',
    body: null,
    headers: {
      'Content-Type' : 'application/json',
      'x-access-token': user.accessToken // especificas que tipo de dato estas mandando en el body
    }
  }).then(response => response.json())
    .then(json => {
      console.log(JSON.stringify(json,null,2));
  });
});*/