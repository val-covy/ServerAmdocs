const express = require('express');
const cors = require('cors');

const app = express();

var corsOptions = {
    origin: "http://localhost:8081"
};

app.use(cors(corsOptions));

//parse requests of content-type application/json
app.use(express.json());

//parse requests of content-type application/x-www-form-urlenconded
app.use(express.urlencoded({extended: true}));

//Sync the DB
const db = require('./app/models');
db.sequelize.sync();
// const Role = db.role;
// const Resource = db.resource;
// const Op = db.Sequelize.Op;
// const Etapa = db.etapa;
// db.sequelize.sync({force: true}).then(() => {
//     console.log('Drop and Resync DB');
//     initial(); 
// });

app.use(express.static("public"));

app.get("/", (req, res) => {
    res.json({
        message: "Welcome to a rest api authentication app with mysql"
    });
});

require('./app/routes/auth.routes')(app);
require('./app/routes/user.routes')(app);

const port = 8080;
app.listen(port, () => {
    console.log("Server is running on port 8080");
});

function initial() {
    Resource.create({
      id: 1,
      name: "/inicio_general.html"
    });

    Resource.create({
      id: 2,
      name: "/inicio_consultant.html"
    });
    
    Resource.create({
      id: 3,
      name: "/inicio_administrador.html"
    });

    Role.create({
      id: 1,
      name: "general"
    }).then(role => {
      Resource.findAll({
        where: {
          name: "/inicio_general.html"
        }
      }).then(resources => {
        role.setResources(resources);
      });
    });

    Role.create({
      id: 2,
      name: "consultant"
    }).then(role => {
      Resource.findAll({
        where: {
          name: {
            [Op.or]: ["/inicio_consultant.html"]
          }
        }
      }).then(resources => {
        role.setResources(resources);
      });
    });

    Role.create({
      id: 3,
      name: "admin"
    }).then(role => {
      Resource.findAll({
        where: {
          name: {
            [Op.or]: ["/inicio_administrador.html"]
          }
        }
      }).then(resources => {
        role.setResources(resources);
      });
    });

    Etapa.create({
      idEtapa: 1,
      nameEtapa: "Offer Requested",
      durationEtapa: 24,
      reminder: 4,
    });
    Etapa.create({
      idEtapa: 2,
      nameEtapa: "Offer Created",
      durationEtapa: 4,
      reminder: 4,
    });
    Etapa.create({
      idEtapa: 3,
      nameEtapa:"Offer Sent to Tap",
      durationEtapa: 24,
      reminder: 4,
    });
    Etapa.create({
      idEtapa: 4,
      nameEtapa: "Offer Sent to Candidate",
      durationEtapa: 8,
      reminder: 4,
    });
    Etapa.create({
      idEtapa: 5,
      nameEtapa: "Offer Sent Back",
      durationEtapa: 24,
      reminder: 8,
    });
    Etapa.create({
      idEtapa: 6,
      nameEtapa: "Final Test start",
      durationEtapa: 8,
      reminder: 8,
    });
    Etapa.create({
      idEtapa: 7,
      nameEtapa: "Final Test Follow UP",
      durationEtapa: 56,
      reminder: 48,
    });
    Etapa.create({
      idEtapa: 8,
      nameEtapa: "Final Test Sent to Tap",
      durationEtapa: 24,
      reminder: 4,
    });
    Etapa.create({
      idEtapa: 9,
      nameEtapa: "Request EA",
      durationEtapa: 8,
      reminder: 8,
    });
    Etapa.create({
      idEtapa: 10,
      nameEtapa: "Create EA",
      durationEtapa: 16,
      reminder: 16,
    });
    Etapa.create({
      idEtapa: 11,
      nameEtapa: "Send EA",
      durationEtapa: 8,
      reminder: 24,
    });
    Etapa.create({
      idEtapa: 12,
      nameEtapa: "Send OnB",
      durationEtapa: 4,
      reminder: 1,
    });
    Etapa.create({
      idEtapa: 13,
      nameEtapa: "Signature FU",
      durationEtapa: 16,
      reminder: 8,
    });
    Etapa.create({
      idEtapa: 14,
      nameEtapa: "OnB FU",
      durationEtapa: 16,
      reminder: 8,
    });
    Etapa.create({
      idEtapa: 15,
      nameEtapa: "Review documents",
      durationEtapa: 8,
      reminder: 4,
    });
    Etapa.create({
      idEtapa: 16,
      nameEtapa: "Doc FU",
      durationEtapa: 8,
      reminder: 4,
    });
    Etapa.create({
      idEtapa: 17,
      nameEtapa: "Load File",
      durationEtapa: 4,
      reminder: 8,
    });
    Etapa.create({
      idEtapa: 18,
      nameEtapa: "Hire",
      durationEtapa: 8,
      reminder: 8,
    });
    Etapa.create({
      idEtapa: 19,
      nameEtapa: "Assets",
      durationEtapa: 8,
      reminder: 8,
    });
    Etapa.create({
      idEtapa: 20,
      nameEtapa: "Assets FU",
      durationEtapa: 24,
      reminder: 8,
    });
    Etapa.create({
      idEtapa: 21,
      nameEtapa: "Confirm joining",
      durationEtapa: 20,
      reminder: 0,
    });

}