module.exports = (sequelize, Sequelize) => {
    const Estatus = sequelize.define("estatus", {
    

        idEstatus: {
            type: Sequelize.STRING,
            allowNull: false
        },
        durationEstatus: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        idCandidato:{
            type: Sequelize.INTEGER,
            allowNull: false
        }


    });
    return Estatus;
};