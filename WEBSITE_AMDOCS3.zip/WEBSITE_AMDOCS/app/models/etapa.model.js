module.exports = (sequelize, Sequelize) => {
    const Etapa = sequelize.define("etapa", {
       
        idEtapa:{
            type: Sequelize.INTEGER,
            primaryKey:true
        },
        nameEtapa:{
            type: Sequelize.STRING,
            allowNull: false
        },
        durationEtapa:{
            type: Sequelize.INTEGER,
            allowNull: false
        },
        reminder:{
            type: Sequelize.INTEGER,
            allowNull: false
        }
    });
    return Etapa;
};