module.exports = (sequelize, Sequelize) => {
    const Candidate = sequelize.define("candidate", {
        idCandidato: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        name: {
            type: Sequelize.STRING,
            allowNull: false
        },
        pi: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        req: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        ol3: {
            type: Sequelize.STRING,
            allowNull: false
        },
        pCenter: {
            type: Sequelize.STRING,
            allowNull: false
        },
        role: {
            type: Sequelize.STRING,
            allowNull: false
        },
        mgr: {
            type: Sequelize.STRING,
            allowNull: false
        },
        idAmdocs: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        wcmBd: {
            type: Sequelize.STRING,
            allowNull: false
        },
        site: {
            type: Sequelize.STRING,
            allowNull: false
        },
        fwd: {
            type: Sequelize.DATEONLY,
            allowNull: false
        },
        tentative: {
            type: Sequelize.DATEONLY,
            allowNull: false
        },
        type: {
            type: Sequelize.STRING,
            allowNull: false
        },
        inv: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        flag: {
            type: Sequelize.BOOLEAN,
            allowNull: false
        },

    });

    return Candidate;
};