const config = require('../config/db.config.js');
const Sequelize = require('sequelize');

const sequelize = new Sequelize(
    config.DB,
    config.USER,
    config.PASSWORD,
    {
        host: config.HOST,
        dialect: config.dialect,
        pool : config.pool
        // {
        //     max: config.pool.max,
        //     min: config.pool.min,
        //     acquire: config.pool.acquire,
        //     idle: config.pool.idle
        // }
    }
);

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.user = require('./user.model.js')(sequelize, Sequelize);
db.role = require('./role.model.js')(sequelize, Sequelize);
db.resource = require('./resource.model.js')(sequelize, Sequelize);
db.candidate = require('./candidate.model.js')(sequelize, Sequelize);
db.estatus = require('./estatus.model.js')(sequelize, Sequelize);
db.etapa = require('./etapa.model.js')(sequelize, Sequelize);

db.role.belongsToMany(db.user, {
    through: "user_roles",
    foreignKey: "roleId",
    otherKey: "userId"
});

db.user.belongsToMany(db.role, {
    through: "user_roles",
    foreignKey: "userId",
    otherKey: "roleId"
});

db.role.belongsToMany(db.resource, {
    through: "role_access",
    foreignKey: "roleId",
    otherKey: "resourceId"
});

db.resource.belongsToMany(db.role, {
    through: "role_access",
    foreignKey: "resourceId",
    otherKey: "roleId"
});

db.etapa.belongsToMany(db.estatus, {
    through: "estatus_etapa",
    foreignKey: "idEtapa",
    otherKey: "idEstatus"
});

db.estatus.belongsToMany(db.etapa, {
    through: "estatus_etapa",
    foreignKey: "idEstatus",
    otherKey: "idEtapa"
});

db.estatus.belongsToMany(db.candidate, {
    through: "estatus_candidate",
    foreignKey: "idCandidato",
    otherKey: "idCandidato"
});

db.ROLES = ["general", "admin", "consultant"];

module.exports = db;