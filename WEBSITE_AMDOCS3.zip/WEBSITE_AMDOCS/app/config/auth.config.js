module.exports = {
    secret: "amdocs-hiring-app"
};