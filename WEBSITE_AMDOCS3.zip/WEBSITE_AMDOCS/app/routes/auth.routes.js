const {verifySignup, authJwt} = require('../middleware');
const controller = require('../controllers/auth.controller');
const controllerCand = require('../controllers/cand.controller');


module.exports = app => {
    app.use((req, res, next) => {
        res.header("Access-Control-Allow-Headers",
        "x-access-token, Origin, Content-Type, Accept");
        next();
    });

    app.get("/api/auth/allUsers",controller.allUsers);
    app.get("/api/auth/allCandidates", controllerCand.allCandidates);
    app.get("/api/auth/allCandidatesWithFlag", controllerCand.allCandidatesWithFlag);

    app.post("/api/auth/Idcandidate", controllerCand.Idcandidate);

    app.post("/api/auth/signup", 
        [
            authJwt.verifyToken,
            authJwt.isAdmin,
            verifySignup.checkDuplicateEmail,
            verifySignup.checkRolesExisted
        ], controller.signup);

    app.post("/api/auth/signin", controller.signin);

    app.delete("/api/auth/errase",controller.errase);

    app.get("/api/auth/isAuthenticated",
        authJwt.verifyToken,
        controller.isAuthenticated);
};