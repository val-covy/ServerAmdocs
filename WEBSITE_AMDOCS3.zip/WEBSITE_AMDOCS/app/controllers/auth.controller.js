const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../models');
const config = require('../config/auth.config');
const { user, role } = require('../models');

const User = db.user;
const Role = db.role;
const Op = db.Sequelize.Op;

module.exports.isAuthenticated = (req, res) => {
    res.send({message: "Authenticated"});
};

module.exports.signup = (req, res) => {
    console.log(req.body);
    User.create({
        username: req.body.username,
        email: req.body.email,
        password: bcrypt.hashSync(req.body.password, 8)
    }).then(user => {
        if (req.body.roles) {
            Role.findAll({
                where: {
                    name: {
                        [Op.or]: req.body.roles
                    }
                }
            }).then(roles => {
                user.setRoles(roles).then(() => {
                    res.send({message: "User was registered successfully"});
                });
            });
        }
    }).catch(err => {
        res.send({message: err.message});
    });
};

module.exports.signin = (req, res) => {
    console.log(req.body);
    User.findOne({
        where: {
            email: req.body.email
        }
    }).then(user => {
        if (!user) {
            return res.status(404).send({message: "User not found"});
        }
        
        var passwordIsValid = bcrypt.compareSync(
            req.body.password,
            user.password
        );

        if (!passwordIsValid) {
            return res.status(401).send({message: "Invalid Password"});
        }

        var token = jwt.sign({id: user.id}, config.secret, {expiresIn: 86400}); //24 horas
        var user_roles = [];
        user.getRoles().then(roles => {
            roles.forEach(elem => {
                user_roles.push(`ROLE_${elem.name.toUpperCase()}`);
            });
            res.status(200).send({
                id: user.id,
                username: user.username,
                email: user.email,
                roles: user_roles,
                accessToken: token
            });
        });
    }).catch(err => {
        res.status(405).send({message: err.message});
    });
};



module.exports.errase = (req, res) => {
    User.destroy({
        where: {
            email: req.body.email
        }
    }).then(user => {
        if (email = req.body.email) {
             res.status(409).send({message: "User deleted"});
        }
    });
};

module.exports.allUsers = (req, res) => {
    User.findAll({
        attributes: ['username','email', 'id']
    }).then(data =>{
        res.send(data);
    })  
};





/*
exports.findAllPublished = (req, res) => {
  Tutorial.findAll({ where: { published: true } })
    .then(data => {
      res.send(data);
    })



  const title = req.query.title;
  var condition = title ? { title: { [Op.like]: `%${title}%` } } : null;

  Tutorial.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
*/

/*module.exports.findAll = (req, res) => {
    const title = req.body.userID;
    user.findOne(req.userId).then(user => {
        user.getRoles().then(roles => {
            roles.forEach(role => {
                role_ids.push(role.id);
            });
        });
    }).catch(err => {
        res.status(409).send({'failed'});
};*/