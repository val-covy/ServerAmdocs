const db = require("../models");
const User = db.user;
const Role = db.role;
const Resource = db.resource;
const Op = db.Sequelize.Op;

module.exports.allAccess = (req, res) => {
    res.status(200).send("Public Content");
};

module.exports.generalAccess = (req, res) => {
    res.status(200).send("General Content");
};

module.exports.adminAccess = (req, res) => {
    res.status(200).send("Admin Content");
};

module.exports.consultantAccess = (req, res) => {
    res.status(200).send("Consultant Content");
};

module.exports.generalAccess = (req, res) => {
    let role_ids = [];
    let resource_names = [];
    User.findByPk(req.userId).then(user => {
        user.getRoles().then(roles => {
            roles.forEach(role => {
                role_ids.push(role.id);
            });

            Resource.findAll({
                include: [{
                    model: Role,
                    attributes: ['id'],
                    where: {
                        id: {
                            [Op.or]: role_ids
                        }
                    }
                }]
            }).then(resources => {
                resources.forEach(resource => {
                    resource_names.push(resource.name);
                });
                res.send({resources: resource_names});
            });
        });
    }).catch(err => {
        res.status(409).send({message: err.message});
    }); 
};