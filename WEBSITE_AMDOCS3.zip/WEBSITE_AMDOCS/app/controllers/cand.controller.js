const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../models');
const config = require('../config/auth.config');
const { candidate, etapa, estatus } = require('../models');

const Candidate = db.candidate;
const Etapa = db.etapa;
const Estatus = db.estatus;

module.exports.allCandidates = (req, res) => {
    Candidate.findAll({
        attributes: ['idCandidato','name', 'role']
    }).then(data =>{
        res.send(data);
    }) 
};


module.exports.allCandidatesWithFlag = (req, res) => {
    Candidate.findAll({
        attributes: ['name', 'role'],
        where:{
            flag: 0
        }
    }).then(data =>{
        res.send(data);
    }) 
};


module.exports.Idcandidate = (req, res) => {
    Candidate.findAll({
        attributes: ['name', 'role'],
        where:{
            idCandidato:req.body.idCandidato
        }
    }).then(data =>{
        res.send(data);
    }) 
};



