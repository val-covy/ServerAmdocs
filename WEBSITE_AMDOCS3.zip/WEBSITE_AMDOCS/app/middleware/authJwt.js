const jwt = require('jsonwebtoken');
const config = require('../config/auth.config.js');
const db = require('../models');

const User = db.user;
[generalRole, adminRole, consultantRole] = db.ROLES;

const verifyToken = (req, res, next) => {
    let token = req.headers["x-access-token"];

    if (!token) {
        return res.status(403).send({
            message: "No token provided"
        });
    }

    jwt.verify(token, config.secret, (err, decoded) => {
        if (err) {
            return res.status(401).send({
                message: "Unauthorized user"
            });
        }
        req.userId = decoded.id;
        next();
    });
};

const isAdmin = (req, res, next) => {
    let adminFound = false;
    User.findByPk(req.userId).then(user => {
        user.getRoles().then(roles => {
            for(let i = 0; i < roles.length; i++) {
                if (roles[i].name === adminRole) {
                    adminFound = true;
                    next();
                }
            }
            if(!adminFound){
                return res.status(403).send({
                    message: "Require Admin Role"
                });
            }
        });
    });
};

const isConsultant = (req, res, next) => {
    let consultantFound = false;
    User.findByPk(req.userId).then(user => {
        user.getRoles().then(roles => {
            for(let i = 0; i < roles.length; i++) {
                if (roles[i].name === consultantRole) {
                    consultantFound = true;
                    next();
                }
            }
            if(!consultantFound){    
                return res.status(403).send({
                    message: "Require Consultant Role"
                });
            }
        });
    });
};

const isGeneral = (req, res, next) => {
    let generalFound = false;
    User.findByPk(req.userId).then(user => {
        user.getRoles().then(roles => {
            for(let i = 0; i < roles.length; i++) {
                if (roles[i].name === generalRole) {
                    generalFound = true;
                    next();
                }
            }
            if(!generalFound){
                return res.status(403).send({
                    message: "Require General Role"
                });
            }
        });
    });
};

const authJwt = {
    verifyToken: verifyToken,
    isAdmin: isAdmin,
    isConsultant: isConsultant,
    isGeneral: isGeneral
};

module.exports = authJwt;