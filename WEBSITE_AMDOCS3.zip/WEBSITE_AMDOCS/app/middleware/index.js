const authJwt = require('./authJwt');
const verifySignup = require('./verifySignUp');

module.exports = {
    authJwt,
    verifySignup
};